
		<div class="fiche"> <!-- begin div class="fiche" -->
		[view.head;strconv=no]
		
			<div class="tabBar">
			
				[view.liste;strconv=no]	
			
			</div>

		</div>
		
